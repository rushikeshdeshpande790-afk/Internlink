<?php
include "config.php";

echo "Connection OK!";
